# VR TCIKETS

Ticket bot for Discord.

## Before hosting
1. In Discord Developer Portal, copy your Application ID (Client ID).
2. Create the role `ticket maneger` in your server.
3. Keep the bot token secret.

## Environment variables
DISCORD_TOKEN = your bot token
CLIENT_ID = your Application ID

## Run
npm install
npm start

Then use `/setup-ticket` in the channel where you want the ticket panel.
