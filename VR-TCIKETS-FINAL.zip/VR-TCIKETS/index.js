require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  REST,
  Routes,
  SlashCommandBuilder,
} = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;

if (!TOKEN) {
  console.error("❌ Missing DISCORD_TOKEN environment variable.");
  process.exit(1);
}

const BOT_NAME = "VR TCIKETS";
const SUPPORT_ROLE_NAME = "ticket maneger";

const commands = [
  new SlashCommandBuilder()
    .setName("setup-ticket")
    .setDescription("Create the VR TCIKETS panel in the current channel."),
  new SlashCommandBuilder()
    .setName("close-ticket")
    .setDescription("Close the current ticket."),
].map(command => command.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
  partials: [Partials.Channel],
});

client.once("ready", async () => {
  console.log(`✅ ${BOT_NAME} is online as ${client.user.tag}`);

  if (CLIENT_ID) {
    try {
      const rest = new REST({ version: "10" }).setToken(TOKEN);
      await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
      console.log("✅ Slash commands registered.");
    } catch (error) {
      console.error("❌ Could not register slash commands:", error);
    }
  } else {
    console.log("⚠️ CLIENT_ID is not set; slash commands were not registered.");
  }

  client.user.setActivity("Ticket Support", { type: 3 });
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "setup-ticket") {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: "❌ لازم تكون Administrator عشان تعمل لوحة التذاكر.",
          ephemeral: true,
        });
      }

      const embed = new EmbedBuilder()
        .setTitle("🎫 VR TCIKETS")
        .setDescription(
          "اضغط على الزر بالأسفل لفتح تذكرة.\n\n" +
          "سيتم إنشاء روم خاص بك وبفريق **ticket maneger**."
        )
        .setFooter({ text: "VR TCIKETS • Ticket System" });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_ticket")
          .setLabel("فتح تذكرة")
          .setEmoji("🎫")
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: "✅ تم إنشاء لوحة التذاكر.", ephemeral: true });
    }

    if (interaction.commandName === "close-ticket") {
      if (!interaction.channel?.name?.startsWith("ticket-")) {
        return interaction.reply({ content: "❌ الأمر ده داخل التذاكر فقط.", ephemeral: true });
      }

      const role = interaction.guild.roles.cache.find(
        r => r.name.toLowerCase() === SUPPORT_ROLE_NAME.toLowerCase()
      );
      const isManager = role && interaction.member.roles.cache.has(role.id);
      const isAdmin = interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator);

      if (!isManager && !isAdmin) {
        return interaction.reply({ content: "❌ مش معاك صلاحية قفل التذكرة.", ephemeral: true });
      }

      await interaction.reply("🔒 جاري إغلاق التذكرة...");
      setTimeout(() => interaction.channel.delete().catch(() => {}), 1500);
    }
  }

  if (interaction.isButton()) {
    if (interaction.customId === "open_ticket") {
      const guild = interaction.guild;

      const existing = guild.channels.cache.find(
        c => c.type === ChannelType.GuildText &&
             c.topic === `ticket-owner:${interaction.user.id}`
      );

      if (existing) {
        return interaction.reply({
          content: `❌ عندك تذكرة مفتوحة بالفعل: ${existing}`,
          ephemeral: true,
        });
      }

      const supportRole = guild.roles.cache.find(
        r => r.name.toLowerCase() === SUPPORT_ROLE_NAME.toLowerCase()
      );

      if (!supportRole) {
        return interaction.reply({
          content: `❌ مش لاقي رتبة **${SUPPORT_ROLE_NAME}**. اعمل الرتبة بنفس الاسم بالضبط.`,
          ephemeral: true,
        });
      }

      const safeName =
        interaction.user.username.toLowerCase().replace(/[^a-z0-9-_]/g, "").slice(0, 20) || "user";

      const channel = await guild.channels.create({
        name: `ticket-${safeName}`,
        type: ChannelType.GuildText,
        topic: `ticket-owner:${interaction.user.id}`,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: interaction.user.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ReadMessageHistory,
              PermissionsBitField.Flags.AttachFiles,
            ],
          },
          {
            id: supportRole.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ReadMessageHistory,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.ManageChannels,
            ],
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setTitle("🎫 VR TCIKETS")
        .setDescription(
          `أهلًا <@${interaction.user.id}> 👋\n\n` +
          "اكتب مشكلتك بالتفصيل، وهيتم الرد عليك من فريق الدعم.\n\n" +
          "🔒 لما تخلص، اضغط **قفل التذكرة**."
        )
        .setFooter({ text: "VR TCIKETS • Ticket System" });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("close_ticket")
          .setLabel("قفل التذكرة")
          .setEmoji("🔒")
          .setStyle(ButtonStyle.Danger)
      );

      await channel.send({
        content: `<@${interaction.user.id}> <@&${supportRole.id}>`,
        embeds: [embed],
        components: [row],
      });

      return interaction.reply({
        content: `✅ تم فتح تذكرتك: ${channel}`,
        ephemeral: true,
      });
    }

    if (interaction.customId === "close_ticket") {
      if (!interaction.channel?.name?.startsWith("ticket-")) {
        return interaction.reply({ content: "❌ دي مش تذكرة.", ephemeral: true });
      }

      const supportRole = interaction.guild.roles.cache.find(
        r => r.name.toLowerCase() === SUPPORT_ROLE_NAME.toLowerCase()
      );

      const isOwner = interaction.channel.topic === `ticket-owner:${interaction.user.id}`;
      const isManager = supportRole && interaction.member.roles.cache.has(supportRole.id);
      const isAdmin = interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator);

      if (!isOwner && !isManager && !isAdmin) {
        return interaction.reply({ content: "❌ مش مسموحلك تقفل التذكرة دي.", ephemeral: true });
      }

      await interaction.reply("🔒 تم قفل التذكرة، سيتم حذف الروم بعد ثانيتين.");
      setTimeout(() => interaction.channel.delete().catch(() => {}), 2000);
    }
  }
});

client.login(TOKEN);
